package com.example.data.repository

import com.example.data.model.CreateQuestionRequest
import com.example.data.model.CreateResultRequest
import com.example.data.model.CreateTestRequest
import com.example.data.model.CreateUserRequest
import com.example.data.model.EnrichedResult
import com.example.data.model.QuestionItem
import com.example.data.model.ResultItem
import com.example.data.model.ResultModel
import com.example.data.model.TestItem
import com.example.data.model.TestModel
import com.example.data.model.UpdateQuestionRequest
import com.example.data.model.UpdateResultRequest
import com.example.data.model.UpdateTestRequest
import com.example.data.model.UpdateTestStatusRequest
import com.example.data.model.UpdateUserDeviceRequest
import com.example.data.model.UpdateUserRequest
import com.example.data.model.User
import com.example.data.remote.SupabaseClientProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import retrofit2.Response
import java.io.IOException

sealed class Resource<out T> {
    data class Success<out T>(val data: T) : Resource<T>()
    data class Error(
        val message: String,
        val isNetworkError: Boolean = false,
        val isDeviceActiveOnAnotherPhone: Boolean = false
    ) : Resource<Nothing>()
    data object Loading : Resource<Nothing>()
}

class TestMitraRepository(
    private val clientProvider: SupabaseClientProvider
) {
    private val usersNameCache = mutableMapOf<Long, String>()

    private fun extractErrorMessage(response: Response<*>): String {
        return try {
            val errorBody = response.errorBody()?.string()
            if (!errorBody.isNullOrBlank()) {
                if (errorBody.contains("JWT expired") || errorBody.contains("invalid claim")) {
                    "Session or API Key expired. Please check Supabase Settings."
                } else if (errorBody.contains("Failed to connect") || errorBody.contains("hostname")) {
                    "Unable to connect to Supabase URL. Please check network."
                } else {
                    errorBody.take(200)
                }
            } else {
                "Server responded with error code: ${response.code()}"
            }
        } catch (_: Exception) {
            "Network error (HTTP ${response.code()})"
        }
    }

    suspend fun checkConnection(): Resource<Boolean> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase credentials not configured. Please set URL & Anon Key.")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.getTests(select = "id,test_name,duration,is_active", order = "id.asc")
            if (response.isSuccessful) {
                Resource.Success(true)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection or unable to reach Supabase: ${e.localizedMessage}", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Connection error: ${e.localizedMessage ?: "Unknown error"}")
        }
    }

    suspend fun login(
        mobileNumber: String,
        password: String,
        currentDeviceId: String,
        forceSwitchDevice: Boolean = false
    ): Resource<User> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase URL and API Key must be configured first.")
        }
        try {
            val api = clientProvider.getApiService()
            val cleanMobile = mobileNumber.trim()
            val response = api.getUserByMobile("eq.$cleanMobile")
            if (!response.isSuccessful) {
                val detailedError = extractErrorMessage(response)
                return@withContext Resource.Error(detailedError)
            }

            val users = response.body().orEmpty()
            if (users.isEmpty()) {
                return@withContext Resource.Error("યુઝર મળ્યો નથી (User not found or invalid password)")
            }

            val matchedUser = users.firstOrNull {
                it.password?.trim() == password.trim()
            }

            if (matchedUser == null) {
                return@withContext Resource.Error("પાસવર્ડ ખોટો છે! (Invalid password)")
            }

            if (matchedUser.deviceId?.trim() == "DEACTIVATED") {
                return@withContext Resource.Error("This account has been deactivated by Super Admin. / આ એકાઉન્ટ સુપર એડમિન દ્વારા નિષ્ક્રિય કરેલ છે.")
            }

            // Single Device Login Restriction for Students:
            if (!matchedUser.isTeacherOrAdmin) {
                val activeDevice = matchedUser.deviceId?.trim()
                val thisDevice = currentDeviceId.trim()

                // If active on another phone/device and user did not explicitly request device switch
                if (!activeDevice.isNullOrBlank() && activeDevice != thisDevice && !forceSwitchDevice) {
                    return@withContext Resource.Error(
                        message = "This account is already active on another device. Please logout from the previous device first.\n\n(અન્ય ઉપકરણ પર સક્રિય છે. Logout કરો અથવા ઉપકરણ બદલો.)",
                        isDeviceActiveOnAnotherPhone = true
                    )
                }

                // Register current device ID in Supabase to make this device the single active device
                try {
                    api.updateUserDeviceId("eq.${matchedUser.id}", UpdateUserDeviceRequest(thisDevice))
                } catch (_: Exception) {
                    // Fail silently if column update issues
                }
            }

            Resource.Success(matchedUser.copy(deviceId = currentDeviceId))
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Login failed: ${e.localizedMessage ?: "Unable to connect to Supabase"}")
        }
    }

    suspend fun clearUserDeviceId(userId: Long): Resource<Unit> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured() || userId <= 0) {
            return@withContext Resource.Success(Unit)
        }
        try {
            val api = clientProvider.getApiService()
            // Reset device_id to empty in Supabase so another device can login cleanly
            api.updateUserDeviceId("eq.$userId", UpdateUserDeviceRequest(""))
            Resource.Success(Unit)
        } catch (_: Exception) {
            Resource.Success(Unit)
        }
    }

    suspend fun verifyUserSession(userId: Long, expectedDeviceId: String?): Resource<User> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured() || userId <= 0) {
            return@withContext Resource.Error("Session invalid")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.getUserById("eq.$userId")
            if (!response.isSuccessful) {
                return@withContext Resource.Error("Account deleted / એકાઉન્ટ મળ્યું નથી")
            }
            val user = response.body()?.firstOrNull()
            if (user == null) {
                return@withContext Resource.Error("Account deleted / એકાઉન્ટ મળ્યું નથી")
            }
            if (user.deviceId?.trim() == "DEACTIVATED") {
                return@withContext Resource.Error("Account deactivated by Super Admin / એકાઉન્ટ નિષ્ક્રિય કરેલ છે")
            }
            if (!user.isTeacherOrAdmin && !expectedDeviceId.isNullOrBlank()) {
                val userDev = user.deviceId?.trim()
                if (!userDev.isNullOrBlank() && userDev != expectedDeviceId.trim()) {
                    return@withContext Resource.Error("Logged in on another device / અન્ય ઉપકરણ પર લૉગ ઇન થયેલ છે")
                }
            }
            Resource.Success(user)
        } catch (e: IOException) {
            Resource.Error("Network error", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error(e.localizedMessage ?: "Session error")
        }
    }

    suspend fun getAllUsers(): Resource<List<User>> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.getAllUsers()
            if (response.isSuccessful) {
                val users = response.body().orEmpty()
                users.forEach { u ->
                    if (u.id != null) {
                        usersNameCache[u.id] = u.name ?: u.mobileNumber
                    }
                }
                Resource.Success(users)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your network.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to load users: ${e.localizedMessage}")
        }
    }

    suspend fun registerUser(
        name: String,
        mobileNumber: String,
        password: String,
        role: String = "student",
        callerUser: User? = null
    ): Resource<User> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        // Security Authorization: Only Super Admin can register users/students/admins
        if (callerUser != null && !callerUser.isSuperAdminUser) {
            return@withContext Resource.Error("Permission denied: Only Super Admin can add users. / માત્ર સુપર એડમિન યુઝર ઉમેરી શકે છે.")
        }
        val cleanName = name.trim()
        val cleanMobile = mobileNumber.trim()
        val cleanPassword = password.trim()
        val cleanRole = if (role.equals("admin", ignoreCase = true) || role.equals("teacher", ignoreCase = true)) "admin" else "student"

        if (cleanName.isBlank()) {
            val label = if (cleanRole == "admin") "Admin Name" else "Student Name"
            return@withContext Resource.Error("$label is required / નામ જરૂરી છે")
        }
        if (cleanMobile.length != 10 || !cleanMobile.all { it.isDigit() }) {
            return@withContext Resource.Error("મોબાઇલ નંબર 10 આંકડાનો હોવો જોઈએ (Valid 10-digit mobile required)")
        }
        if (cleanPassword.isBlank()) {
            return@withContext Resource.Error("Password is required / પાસવર્ડ જરૂરી છે")
        }

        try {
            val api = clientProvider.getApiService()
            val checkResp = api.getUserByMobile("eq.$cleanMobile")
            if (checkResp.isSuccessful && !checkResp.body().isNullOrEmpty()) {
                return@withContext Resource.Error("આ મોબાઇલ નંબર પહેલેથી રજીસ્ટર છે! (Mobile number already exists)")
            }

            val req = CreateUserRequest(
                name = cleanName,
                mobileNumber = cleanMobile,
                password = cleanPassword,
                role = cleanRole,
                isSuperAdmin = false
            )
            val response = api.createUser(req)
            if (response.isSuccessful) {
                val created = response.body()?.firstOrNull() ?: User(name = cleanName, mobileNumber = cleanMobile, role = cleanRole, isSuperAdmin = false)
                if (created.id != null) {
                    usersNameCache[created.id] = created.name ?: created.mobileNumber
                }
                Resource.Success(created)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection to save user.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to add user: ${e.localizedMessage}")
        }
    }

    suspend fun updateUser(
        userId: Long,
        name: String,
        password: String? = null,
        callerUser: User? = null,
        mobileNumber: String? = null
    ): Resource<User> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        if (callerUser != null && !callerUser.isSuperAdminUser) {
            return@withContext Resource.Error("Permission denied: Only Super Admin can edit users. / માત્ર સુપર એડમિન ફેરફાર કરી શકે છે.")
        }
        val cleanName = name.trim()
        if (cleanName.isBlank()) {
            return@withContext Resource.Error("Name is required / નામ જરૂરી છે")
        }
        val cleanMobile = mobileNumber?.trim()?.ifBlank { null }
        if (cleanMobile != null) {
            if (cleanMobile.length != 10 || !cleanMobile.all { it.isDigit() }) {
                return@withContext Resource.Error("Enter valid 10-digit mobile number / 10 અંકનો માન્ય મોબાઇલ નંબર દાખલ કરો")
            }
        }
        val cleanPassword = password?.trim()?.ifBlank { null }

        try {
            val api = clientProvider.getApiService()
            // If changing mobile number, check if it's already used by another user
            if (cleanMobile != null) {
                val existingUsers = try {
                    val resp = api.getUserByMobile("eq.$cleanMobile")
                    if (resp.isSuccessful) resp.body().orEmpty() else emptyList()
                } catch (_: Exception) {
                    emptyList()
                }
                val duplicate = existingUsers.firstOrNull { it.id != userId }
                if (duplicate != null) {
                    return@withContext Resource.Error("This mobile number is already registered / આ મોબાઇલ નંબર પહેલેથી રજિસ્ટર થયેલ છે")
                }
            }

            val req = UpdateUserRequest(
                name = cleanName,
                mobileNumber = cleanMobile,
                password = cleanPassword
            )
            val response = api.updateUser("eq.$userId", req)
            if (response.isSuccessful) {
                val updated = response.body()?.firstOrNull() ?: User(id = userId, name = cleanName, mobileNumber = cleanMobile ?: "")
                usersNameCache[userId] = cleanName
                Resource.Success(updated)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection to update user.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to update user: ${e.localizedMessage}")
        }
    }

    suspend fun deleteUser(userId: Long, callerUser: User? = null): Resource<Unit> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        if (callerUser != null && !callerUser.isSuperAdminUser) {
            return@withContext Resource.Error("Permission denied: Only Super Admin can delete users. / માત્ર સુપર એડમિન યુઝર ડિલીટ કરી શકે છે.")
        }
        if (userId == 1L || (callerUser != null && userId == callerUser.id)) {
            return@withContext Resource.Error("Cannot delete Super Admin account / સુપર એડમિન એકાઉન્ટ ડિલીટ કરી શકાતું નથી")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.deleteUser("eq.$userId")
            if (response.isSuccessful) {
                usersNameCache.remove(userId)
                Resource.Success(Unit)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to delete user: ${e.localizedMessage}")
        }
    }

    suspend fun toggleAdminActiveStatus(
        adminId: Long,
        deactivate: Boolean,
        callerUser: User? = null
    ): Resource<Unit> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        if (callerUser != null && !callerUser.isSuperAdminUser) {
            return@withContext Resource.Error("Permission denied: Only Super Admin can activate/deactivate admins.")
        }
        if (adminId == 1L) {
            return@withContext Resource.Error("Cannot deactivate Super Admin.")
        }
        try {
            val api = clientProvider.getApiService()
            val newDeviceId = if (deactivate) "DEACTIVATED" else ""
            val response = api.updateUserDeviceId("eq.$adminId", UpdateUserDeviceRequest(newDeviceId))
            if (response.isSuccessful) {
                Resource.Success(Unit)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to update admin status: ${e.localizedMessage}")
        }
    }

    suspend fun getTests(): Resource<List<TestItem>> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.getTests(order = "id.desc")
            if (response.isSuccessful) {
                val tests = response.body().orEmpty().sortedByDescending { it.id ?: 0L }
                Resource.Success(tests)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your network.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to load tests: ${e.localizedMessage}")
        }
    }

    suspend fun updateTestStatus(testId: Long, isActive: Boolean): Resource<Unit> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.updateTestStatus("eq.$testId", UpdateTestStatusRequest(isActive))
            if (response.isSuccessful) {
                Resource.Success(Unit)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to update test status: ${e.localizedMessage}")
        }
    }

    suspend fun getAllQuestions(): Resource<List<QuestionItem>> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.getAllQuestions()
            if (response.isSuccessful) {
                Resource.Success(response.body().orEmpty())
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your network.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to load questions: ${e.localizedMessage}")
        }
    }

    suspend fun getQuestionsForTest(testId: Long): Resource<List<QuestionItem>> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.getQuestionsForTest("eq.$testId")
            if (response.isSuccessful) {
                val questions = response.body().orEmpty().sortedBy { it.id ?: 0L }
                Resource.Success(questions)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your network.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to load questions: ${e.localizedMessage}")
        }
    }

    /**
     * Reliable Result Saving Logic
     * Works for Students, Admins, and Super Admins taking tests.
     */
    suspend fun submitResult(
        userId: Long,
        testId: Long,
        score: Double,
        userMobile: String = ""
    ): Resource<ResultItem> = withContext(Dispatchers.IO + NonCancellable) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase is not configured. Please check connection.")
        }
        val api = clientProvider.getApiService()

        // 1. Resolve effective User ID with 100% accuracy
        var effectiveUserId = userId
        if (effectiveUserId <= 0 && userMobile.isNotBlank()) {
            try {
                val userResp = api.getUserByMobile("eq.${userMobile.trim()}")
                if (userResp.isSuccessful) {
                    val foundUser = userResp.body()?.firstOrNull()
                    if (foundUser?.id != null && foundUser.id > 0) {
                        effectiveUserId = foundUser.id
                    }
                }
            } catch (_: Exception) {}
        }

        if (effectiveUserId <= 0) {
            return@withContext Resource.Error("User identification failed. Please log in again before submitting test.")
        }

        val createReq = CreateResultRequest(userId = effectiveUserId, testId = testId, score = score.toInt())
        val updateReq = UpdateResultRequest(score = score.toInt())
        var lastErrorMsg = "Unable to save result to Supabase server."
        var isNetError = false

        // 2. Perform saving with up to 3 automatic retry attempts
        for (attempt in 1..3) {
            try {
                // Step A: Check if this user already has a result for this test
                val checkResponse = api.getResultForUserAndTest("eq.$effectiveUserId", "eq.$testId")
                if (checkResponse.isSuccessful) {
                    val existingRows = checkResponse.body().orEmpty()
                    if (existingRows.isNotEmpty()) {
                        // Matching row already exists: Update existing result row
                        val existingRow = existingRows.first()
                        val patchResp = if (existingRow.id != null && existingRow.id > 0) {
                            api.updateResultById("eq.${existingRow.id}", updateReq)
                        } else {
                            api.updateResult("eq.$effectiveUserId", "eq.$testId", updateReq)
                        }
                        if (patchResp.isSuccessful && !patchResp.body().isNullOrEmpty()) {
                            return@withContext Resource.Success(patchResp.body()!!.first())
                        } else if (!patchResp.isSuccessful) {
                            lastErrorMsg = extractErrorMessage(patchResp)
                        }
                    } else {
                        // No existing row: Perform INSERT into results table
                        val insertResp = api.submitResult(createReq)
                        if (insertResp.isSuccessful && !insertResp.body().isNullOrEmpty()) {
                            return@withContext Resource.Success(insertResp.body()!!.first())
                        } else if (insertResp.isSuccessful) {
                            val verifyResp = api.getResultForUserAndTest("eq.$effectiveUserId", "eq.$testId")
                            if (verifyResp.isSuccessful && !verifyResp.body().isNullOrEmpty()) {
                                return@withContext Resource.Success(verifyResp.body()!!.first())
                            }
                        } else {
                            lastErrorMsg = extractErrorMessage(insertResp)
                        }
                    }
                } else {
                    lastErrorMsg = extractErrorMessage(checkResponse)
                }

                // Step B: Fallback attempt with direct Upsert or Update
                val upsertResp = try {
                    api.upsertResult(onConflict = "user_id,test_id", result = createReq)
                } catch (_: Exception) { null }
                if (upsertResp != null && upsertResp.isSuccessful && !upsertResp.body().isNullOrEmpty()) {
                    return@withContext Resource.Success(upsertResp.body()!!.first())
                }

                val directPatch = api.updateResult("eq.$effectiveUserId", "eq.$testId", updateReq)
                if (directPatch.isSuccessful && !directPatch.body().isNullOrEmpty()) {
                    return@withContext Resource.Success(directPatch.body()!!.first())
                }

                // Step C: Direct verification query on Supabase to verify presence of result
                val finalVerification = api.getResultForUserAndTest("eq.$effectiveUserId", "eq.$testId")
                if (finalVerification.isSuccessful && !finalVerification.body().isNullOrEmpty()) {
                    val confirmedItem = finalVerification.body()!!.first()
                    return@withContext Resource.Success(confirmedItem)
                }
            } catch (e: IOException) {
                isNetError = true
                lastErrorMsg = "Internet connection error while saving result: ${e.localizedMessage}"
            } catch (e: Exception) {
                lastErrorMsg = e.localizedMessage ?: "Unexpected error during result save"
            }
            if (attempt < 3) {
                delay(attempt * 400L)
            }
        }

        Resource.Error(
            message = if (isNetError) "No internet connection. Result could not be saved to Supabase: $lastErrorMsg" else lastErrorMsg,
            isNetworkError = isNetError
        )
    }

    suspend fun getStudentResults(userId: Long, userMobile: String = ""): Resource<List<EnrichedResult>> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            var effectiveUserId = userId
            if (effectiveUserId <= 0 && userMobile.isNotBlank()) {
                try {
                    val userResp = api.getUserByMobile("eq.${userMobile.trim()}")
                    if (userResp.isSuccessful) {
                        effectiveUserId = userResp.body()?.firstOrNull()?.id ?: 0L
                    }
                } catch (_: Exception) {}
            }

            val resultsResp = if (effectiveUserId > 0) {
                api.getResultsForUser("eq.$effectiveUserId")
            } else {
                api.getResults(select = "*", order = "id.desc")
            }
            val testsResp = try { api.getTests(order = "id.asc") } catch (_: Exception) { null }

            if (resultsResp.isSuccessful) {
                val results = resultsResp.body().orEmpty()
                val testsMap = testsResp?.body().orEmpty().associateBy { it.id ?: 0L }
                val distinctResults = results.distinctBy { it.testId }
                val enriched = distinctResults.map { res ->
                    val test = testsMap[res.testId]
                    EnrichedResult(
                        id = res.id,
                        userId = res.userId,
                        userMobile = userMobile,
                        testId = res.testId,
                        testName = test?.testName ?: "Test #${res.testId}",
                        testDuration = test?.duration ?: 0,
                        score = res.score,
                        createdAt = res.createdAt
                    )
                }
                Resource.Success(enriched)
            } else {
                Resource.Error(extractErrorMessage(resultsResp))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your network.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to load results: ${e.localizedMessage}")
        }
    }

    /**
     * Complete Results Table Query for Admin & Super Admin (from TEST MITRA RESULTS)
     */
    suspend fun getResultsForTestAdmin(testId: Long, testTotalMarks: Double? = null): Resource<List<ResultModel>> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()

            // Preload users cache if empty
            if (usersNameCache.isEmpty()) {
                val usersResp = api.getAllUsers()
                if (usersResp.isSuccessful) {
                    usersResp.body().orEmpty().forEach { u ->
                        if (u.id != null) {
                            usersNameCache[u.id] = u.name ?: u.mobileNumber
                        }
                    }
                }
            }

            val response = api.getResultsForTest("eq.$testId")
            if (response.isSuccessful) {
                val results = response.body().orEmpty()
                val mapped = results.mapIndexed { idx, item ->
                    val studentName = usersNameCache[item.userId] ?: "વિદ્યાર્થી #${item.userId}"
                    ResultModel(
                        id = item.id?.toString() ?: idx.toString(),
                        testId = testId.toString(),
                        studentName = studentName,
                        score = item.score,
                        totalMarks = testTotalMarks,
                        createdAt = item.createdAt
                    )
                }.sortedByDescending { it.score }
                Resource.Success(mapped)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your network.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to load test results: ${e.localizedMessage}")
        }
    }

    suspend fun createTest(testName: String, durationMinutes: Int): Resource<TestItem> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val cleanName = testName.trim()
            val api = clientProvider.getApiService()
            val req = CreateTestRequest(testName = cleanName, duration = durationMinutes, isActive = true)
            val response = api.createTest(req)
            if (response.isSuccessful) {
                val created = response.body()?.firstOrNull() ?: TestItem(testName = cleanName, duration = durationMinutes, isActive = true)
                Resource.Success(created)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection to create test.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to create test: ${e.localizedMessage}")
        }
    }

    suspend fun updateTest(testId: Long, testName: String, durationMinutes: Int): Resource<TestItem> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val cleanName = testName.trim()
            val api = clientProvider.getApiService()
            val req = UpdateTestRequest(testName = cleanName, duration = durationMinutes)
            val response = api.updateTest("eq.$testId", req)
            if (response.isSuccessful) {
                val updated = response.body()?.firstOrNull() ?: TestItem(id = testId, testName = cleanName, duration = durationMinutes)
                Resource.Success(updated)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection to update test.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to update test: ${e.localizedMessage}")
        }
    }

    suspend fun deleteTest(testId: Long, callerUser: User? = null): Resource<Unit> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        if (callerUser != null && !callerUser.isSuperAdminUser) {
            return@withContext Resource.Error("Permission denied: Only Super Admin can delete tests.")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.deleteTest("eq.$testId")
            if (response.isSuccessful) {
                Resource.Success(Unit)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to delete test: ${e.localizedMessage}")
        }
    }

    suspend fun addQuestion(
        testId: Long,
        questionText: String,
        optionA: String,
        optionB: String,
        optionC: String,
        optionD: String,
        correctOption: String
    ): Resource<QuestionItem> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val req = CreateQuestionRequest(
                testId = testId,
                questionText = questionText.trim(),
                optionA = optionA.trim(),
                optionB = optionB.trim(),
                optionC = optionC.trim(),
                optionD = optionD.trim(),
                correctOption = correctOption.trim().uppercase()
            )
            val response = api.createQuestion(req)
            if (response.isSuccessful) {
                val created = response.body()?.firstOrNull() ?: QuestionItem(
                    testId = testId,
                    questionText = questionText,
                    optionA = optionA,
                    optionB = optionB,
                    optionC = optionC,
                    optionD = optionD,
                    correctOption = correctOption
                )
                Resource.Success(created)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection to save question.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to save question: ${e.localizedMessage}")
        }
    }

    suspend fun updateQuestion(
        questionId: Long,
        questionText: String,
        optionA: String,
        optionB: String,
        optionC: String,
        optionD: String,
        correctOption: String
    ): Resource<QuestionItem> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val req = UpdateQuestionRequest(
                questionText = questionText.trim(),
                optionA = optionA.trim(),
                optionB = optionB.trim(),
                optionC = optionC.trim(),
                optionD = optionD.trim(),
                correctOption = correctOption.trim().uppercase()
            )
            val response = api.updateQuestion("eq.$questionId", req)
            if (response.isSuccessful) {
                val updated = response.body()?.firstOrNull() ?: QuestionItem(
                    id = questionId,
                    testId = 0L,
                    questionText = questionText,
                    optionA = optionA,
                    optionB = optionB,
                    optionC = optionC,
                    optionD = optionD,
                    correctOption = correctOption
                )
                Resource.Success(updated)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection to update question.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to update question: ${e.localizedMessage}")
        }
    }

    suspend fun deleteQuestion(questionId: Long, callerUser: User? = null): Resource<Unit> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        if (callerUser != null && !callerUser.isSuperAdminUser) {
            return@withContext Resource.Error("Permission denied: Only Super Admin can delete questions.")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.deleteQuestion("eq.$questionId")
            if (response.isSuccessful) {
                Resource.Success(Unit)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to delete question: ${e.localizedMessage}")
        }
    }
}
